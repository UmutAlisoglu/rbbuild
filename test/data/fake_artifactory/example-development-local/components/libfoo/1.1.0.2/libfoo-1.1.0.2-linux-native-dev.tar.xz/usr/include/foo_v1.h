// libfoo 1.1.0.2
